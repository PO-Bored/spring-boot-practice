package com.example.myspringbootpractice.dao.implement;


import com.example.myspringbootpractice.dao.UserDao;
import com.example.myspringbootpractice.dto.User;
import com.example.myspringbootpractice.rowMapper.UserRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class UserDaoImp implements UserDao {

    @Autowired
    NamedParameterJdbcTemplate jdbcTemplate;

    @Override
    public User getUserById(int id) {
        String sql = "select * from user where id = :id";

        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        List<User> user =jdbcTemplate.query(sql,params,new UserRowMapper());

        if(user.size()>0){
            return user.get(0);
        }else{
            return null;
        }

    }

    @Override
    public Integer createUser(User user) {

        String sql = "Insert into user(name,account,password,phone,email) " +
                "values(:name,:account,:password,:phone,:email)";

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(sql, new BeanPropertySqlParameterSource(user), keyHolder);
        int id = keyHolder.getKey().intValue();
        return id;
    }
}
