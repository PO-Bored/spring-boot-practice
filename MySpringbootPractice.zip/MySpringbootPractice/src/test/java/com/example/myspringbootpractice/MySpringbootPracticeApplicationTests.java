package com.example.myspringbootpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringbootPracticeApplicationTests {

    @Test
    void contextLoads() {
    }

}
